import asyncio
import ccxt
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, Optional, List, Any
from loguru import logger
import json

from .indicators import Indicators
from .risk_management import RiskManager
from .config import Config

class TradingBot:
    def __init__(self, config_path: str = None):
        self.config = Config(config_path).get_all()
        # Use async-compatible exchange
        self.exchange = self._initialize_exchange()
        self.indicators = Indicators()
        
        risk_settings = Config(config_path).get_risk_settings()
        self.risk_manager = RiskManager(
            balance=float(self.get_balance()),
            risk_per_trade=risk_settings['risk_per_trade'],
            max_drawdown=risk_settings['max_drawdown'],
            position_size_limit=risk_settings['position_size_limit']
        )
        
        self.active_trades: Dict[str, Dict] = {}
        
        # Filter valid trading pairs
        self.trading_pairs = self._validate_trading_pairs(
            Config(config_path).get_trading_pairs()
        )
        
        self.timeframes = Config(config_path).get_timeframes()
        
    def _initialize_exchange(self):
        """
        Initialize async-compatible exchange with robust configuration
        
        Supports multiple trading modes: spot, futures, margin
        Handles different exchange configurations
        """
        try:
            exchange_id = self.config.get('exchange', 'binance').lower()
            trading_mode = self.config.get('trading_mode', 'spot').lower()
            
            # Get credentials from config
            credentials = Config(None).get_exchange_credentials()
            
            # Exchange configuration
            exchange_config = {
                'apiKey': credentials['api_key'],
                'secret': credentials['api_secret'],
                'enableRateLimit': True,
                'options': {
                    'defaultType': 'spot'  # Default to spot trading
                }
            }
            
            # Specialized configurations
            if trading_mode == 'futures':
                exchange_config['options']['defaultType'] = 'future'
            elif trading_mode == 'margin':
                exchange_config['options']['defaultType'] = 'margin'
            
            # Initialize exchange
            exchange_class = getattr(ccxt, exchange_id)
            exchange = exchange_class(exchange_config)
            
            # Verify exchange connectivity
            exchange.load_markets()
            
            logger.info(f"Exchange {exchange_id} initialized in {trading_mode} mode")
            return exchange
        
        except ccxt.NetworkError:
            logger.error("Network error connecting to exchange. Check internet connection.")
            raise
        except ccxt.AuthenticationError:
            logger.error("Authentication failed. Check API key and secret.")
            raise
        except Exception as e:
            logger.error(f"Failed to initialize exchange: {str(e)}")
            raise

    def get_balance(self) -> float:
        """
        Retrieve account balance with comprehensive error handling
        
        Returns:
            float: Total account balance in USDT
        """
        try:
            # Fetch balance with multiple retry strategies
            balance_strategies = [
                lambda: self.exchange.fetch_balance(),
                lambda: self.exchange.fetch_total_balance(),
                lambda: self.exchange.privateGetBalance()
            ]
            
            for strategy in balance_strategies:
                try:
                    balance = strategy()
                    
                    # Multiple balance retrieval methods
                    balance_methods = [
                        lambda b: b.get('total', {}).get('USDT', 0.0),
                        lambda b: b.get('free', {}).get('USDT', 0.0),
                        lambda b: b.get('USDT', {}).get('total', 0.0),
                        lambda b: sum(float(v) for v in b.get('total', {}).values() if isinstance(v, (int, float))),
                        lambda b: sum(float(v) for v in b.get('free', {}).values() if isinstance(v, (int, float)))
                    ]
                    
                    for method in balance_methods:
                        try:
                            bal = method(balance)
                            if isinstance(bal, (int, float)) and bal > 0:
                                logger.info(f"Balance retrieved: {bal} USDT")
                                return float(bal)
                        except Exception:
                            continue
                
                except Exception as strategy_error:
                    logger.warning(f"Balance retrieval strategy failed: {strategy_error}")
                    continue
            
            logger.error("Unable to retrieve balance from any strategy")
            return 0.0
        
        except ccxt.AuthenticationError:
            logger.error("Authentication failed. Verify API key permissions.")
            return 0.0
        except ccxt.NetworkError:
            logger.error("Network error while fetching balance.")
            return 0.0
        except Exception as e:
            logger.error(f"Unexpected balance retrieval error: {e}")
            return 0.0
            
    async def fetch_ohlcv(self, symbol: str, timeframe: str) -> Optional[pd.DataFrame]:
        """
        Fetch OHLCV data with proper async handling and error recovery

        Args:
            symbol: Trading pair symbol
            timeframe: Timeframe for candlestick data
            
        Returns:
            Optional[pd.DataFrame]: OHLCV data as DataFrame or None on error
        """
        try:
            # Use synchronous fetch method wrapped in run_in_executor
            loop = asyncio.get_event_loop()
            ohlcv = await loop.run_in_executor(
                None, 
                lambda: self.exchange.fetch_ohlcv(symbol, timeframe)
            )
            
            if not ohlcv or len(ohlcv) < 30:  # Minimum required candles
                logger.warning(f"Insufficient OHLCV data for {symbol} on {timeframe}")
                return None
                
            # Convert to DataFrame
            df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            return df
            
        except ccxt.NetworkError as e:
            logger.error(f"Network error fetching OHLCV data for {symbol}: {str(e)}")
            return None
        except ccxt.ExchangeError as e:
            logger.error(f"Exchange error fetching OHLCV data for {symbol}: {str(e)}")
            return None
        except Exception as e:
            logger.error(f"Error fetching OHLCV data for {symbol}: {str(e)}")
            return None

    async def analyze_market(self, symbol: str, timeframe: str) -> Optional[Dict[str, Any]]:
        """
        Comprehensive market analysis for a specific trading pair
        
        Args:
            symbol (str): Trading pair symbol
            timeframe (str): Timeframe for analysis
        
        Returns:
            Optional[Dict[str, Any]]: Market analysis results or None
        """
        try:
            # Fetch OHLCV data
            df = await self.fetch_ohlcv(symbol, timeframe)
            
            if df is None:
                logger.warning(f"No OHLCV data available for {symbol}")
                return None
            
            # Calculate technical indicators
            try:
                # Generate comprehensive signal
                signal = self.indicators.generate_signal(df)
                
                # Log detailed signal information
                logger.info(f"Market Analysis for {symbol}: {json.dumps(signal)}")
                
                return {
                    "symbol": symbol,
                    "timeframe": timeframe,
                    "action": signal.get('action', 'hold'),
                    "confidence": signal.get('confidence', 0.0),
                    "score": signal.get('score', 0.0),
                    "price": signal.get('price', 0.0),
                    "reasons": signal.get('reasons', [])
                }
            
            except Exception as indicator_error:
                logger.error(f"Indicator calculation error for {symbol}: {indicator_error}")
                return None
        
        except Exception as e:
            logger.error(f"Market analysis error for {symbol}: {e}")
            return None

    async def execute_trade(self, symbol: str, side: str, size: float) -> bool:
        """Execute trade on exchange with comprehensive logging"""
        try:
            # Fetch current market price
            ticker = await self.exchange.fetch_ticker(symbol)
            current_price = ticker['last']
            
            # Prepare trade parameters
            trade_params = {
                'symbol': symbol,
                'type': 'market',
                'side': side,
                'amount': size
            }
            
            # Execute trade
            trade_result = await self.exchange.create_order(**trade_params)
            
            # Log trade details
            logger.info(f"Trade executed for {symbol}: "
                        f"Side: {side}, "
                        f"Size: {size}, "
                        f"Price: {current_price}, "
                        f"Total Value: {size * current_price}")
            
            # Update active trades if it's a buy order
            if side == 'buy':
                self.active_trades[symbol] = {
                    'entry_price': current_price,
                    'position_size': size,
                    'timestamp': datetime.now()
                }
            
            return True
        except Exception as e:
            logger.error(f"Error executing trade for {symbol}: {e}")
            return False
            
    async def manage_trades(self):
        """Manage existing trades"""
        try:
            for symbol, trade in self.active_trades.items():
                loop = asyncio.get_event_loop()
                current_price = float((await loop.run_in_executor(
                    None, 
                    lambda: self.exchange.fetch_ticker(symbol)
                ))['last'])
                
                # Check stop loss
                if trade['side'] == 'buy' and current_price <= trade['stop_loss']:
                    await self.execute_trade(symbol, 'sell', trade['size'])
                    del self.active_trades[symbol]
                    logger.info(f"Stop loss triggered for {symbol}")
                    
                elif trade['side'] == 'sell' and current_price >= trade['stop_loss']:
                    await self.execute_trade(symbol, 'buy', trade['size'])
                    del self.active_trades[symbol]
                    logger.info(f"Stop loss triggered for {symbol}")
                    
                # Update trade metrics
                trade['current_price'] = current_price
                trade['pnl'] = self._calculate_pnl(trade)
                
        except Exception as e:
            logger.error(f"Error managing trades: {e}")
            
    def _calculate_pnl(self, trade: Dict) -> float:
        """Calculate unrealized PnL for a trade"""
        if trade['side'] == 'buy':
            return (trade['current_price'] - trade['entry_price']) * trade['size']
        return (trade['entry_price'] - trade['current_price']) * trade['size']
        
    async def run(self):
        """
        Main trading bot execution loop
        Manages active trades, analyzes markets, and executes trades
        """
        logger.info("Starting trading bot in live mode")
        
        while True:
            try:
                # Update balance
                current_balance = self.get_balance()
                self.risk_manager.update_balance(current_balance)
                
                # Manage existing trades
                await self.manage_trades()
                
                # Analyze markets and execute new trades
                for symbol in self.trading_pairs:
                    if symbol not in self.active_trades and self.risk_manager.can_open_trade():
                        analysis = await self.analyze_market(symbol, self.timeframes['primary'])
                        
                        # Updated signal processing
                        if analysis and analysis.get('action') == 'buy' and analysis.get('confidence', 0) >= 0.4:
                            # Calculate position size
                            loop = asyncio.get_event_loop()
                            position_size = self.risk_manager.calculate_position_size(
                                price=analysis.get('price', 0),
                                risk_per_trade=self.risk_manager.risk_per_trade
                            )
                            
                            # Execute trade
                            if position_size > 0:
                                trade_success = await self.execute_trade(
                                    symbol=symbol, 
                                    side='buy', 
                                    size=position_size
                                )
                                
                                if trade_success:
                                    self.active_trades[symbol] = {
                                        'entry_price': analysis.get('price', 0),
                                        'position_size': position_size,
                                        'timestamp': datetime.now()
                                    }
                
                # Sleep to prevent excessive API calls
                await asyncio.sleep(self.config.get('trading_interval', 300))
            
            except Exception as e:
                logger.error(f"Error in trading bot main loop: {e}")
                await asyncio.sleep(60)  # Wait before retrying
                
    def _validate_trading_pairs(self, pairs: List[str]) -> List[str]:
        """
        Validate trading pairs against exchange markets
        
        Args:
            pairs: List of trading pairs to validate
        
        Returns:
            List of valid trading pairs
        """
        valid_pairs = []
        try:
            # Fetch available markets from the exchange
            markets = self.exchange.load_markets()
            
            for pair in pairs:
                if pair in markets:
                    valid_pairs.append(pair)
                else:
                    logger.warning(f"Trading pair {pair} not available on exchange. Skipping.")
            
            if not valid_pairs:
                logger.error("No valid trading pairs found. Check your configuration.")
            
            return valid_pairs
        
        except Exception as e:
            logger.error(f"Error validating trading pairs: {e}")
            return []

    def _calculate_stop_loss(self, current_price: float, analysis: Dict) -> float:
        """Calculate stop loss price based on ATR and signal strength"""
        atr = analysis.get('higher_tf', {}).get('atr', current_price * 0.02)  # Default to 2% if ATR not available
        
        if analysis['signal'] == 'buy':
            return current_price - (2 * atr)
        return current_price + (2 * atr)
