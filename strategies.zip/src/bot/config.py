import os
import yaml
from typing import Dict, Any
from loguru import logger

class Config:
    def __init__(self, config_path: str = None):
        if config_path is None:
            config_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
                'config',
                'config.yaml'
            )
        
        self.config_path = config_path
        self.config_data = self._load_config()
        
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from YAML file"""
        try:
            with open(self.config_path, 'r') as f:
                config = yaml.safe_load(f)
            logger.info("Configuration loaded successfully")
            return config
        except Exception as e:
            logger.error(f"Error loading configuration: {e}")
            raise
            
    def get_exchange_credentials(self) -> Dict[str, str]:
        """Get exchange API credentials"""
        exchange = self.config_data['exchange']
        return self.config_data['api_keys'][exchange]
        
    def get_trading_pairs(self) -> list:
        """Get configured trading pairs"""
        return self.config_data['trading_pairs']
        
    def get_timeframes(self) -> Dict[str, str]:
        """Get configured timeframes"""
        return self.config_data['timeframes']
        
    def get_risk_settings(self) -> Dict[str, float]:
        """Get risk management settings"""
        return {
            'risk_per_trade': self.config_data['risk_per_trade'],
            'max_open_trades': self.config_data['max_open_trades'],
            'max_drawdown': self.config_data['max_drawdown'],
            'position_size_limit': self.config_data['position_size_limit']
        }
        
    def get_trading_mode(self) -> str:
        """Get trading mode (paper/live)"""
        return self.config_data['trading_mode']
        
    def get_all(self) -> Dict[str, Any]:
        """Get entire configuration"""
        return self.config_data
