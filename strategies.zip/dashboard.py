import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objs as go
from typing import List, Dict, Any
import ccxt
import yaml
import os
import logging
import re
import json
import ast
from datetime import datetime, timedelta
import numpy as np
from pathlib import Path
from loguru import logger
import time
import traceback

class AdvancedTradingDashboard:
    def __init__(self, config_path: str = None):
        # Default config path
        if config_path is None:
            config_path = os.path.join(
                os.path.dirname(__file__),
                'config',
                'config.yaml'
            )
        
        # Load configuration
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        # Initialize exchange
        self.exchange = self._initialize_exchange()
        
        # Log file path
        self.log_file_path = os.path.join(
            os.path.dirname(__file__),
            'data',
            'logs',
            'trading_bot.log'
        )
        
        # Ensure logs directory exists
        os.makedirs(os.path.dirname(self.log_file_path), exist_ok=True)
        
        # Create an empty log file if it doesn't exist
        if not os.path.exists(self.log_file_path):
            open(self.log_file_path, 'a').close()
        
        self.setup_page_config()
        
    def _initialize_exchange(self):
        """Initialize exchange with API credentials"""
        try:
            exchange_class = getattr(ccxt, self.config['exchange'])
            exchange = exchange_class({
                'apiKey': self.config['api_keys']['binance']['api_key'],
                'secret': self.config['api_keys']['binance']['api_secret'],
                'enableRateLimit': True,
                'options': {'defaultType': 'spot'}
            })
            return exchange
        except Exception as e:
            st.error(f"Exchange initialization error: {e}")
            return None

    def fetch_live_balance(self):
        """Fetch live account balance from exchange"""
        try:
            balance = self.exchange.fetch_balance()
            usdt_balance = balance['total'].get('USDT', 0.0)
            return usdt_balance
        except Exception as e:
            st.warning(f"Could not fetch live balance: {e}")
            return None

    def fetch_open_trades(self):
        """Fetch open trades from exchange with improved handling"""
        try:
            # Suppress the rate limit warning
            self.exchange.options['warnOnFetchOpenOrdersWithoutSymbol'] = False
            
            # Fetch open trades for each trading pair
            open_trades = []
            for symbol in self.config['trading_pairs']:
                try:
                    symbol_trades = self.exchange.fetch_open_orders(symbol)
                    open_trades.extend(symbol_trades)
                except Exception as e:
                    st.warning(f"Could not fetch open trades for {symbol}: {e}")
            
            return open_trades
        except Exception as e:
            st.warning(f"Error fetching open trades: {e}")
            return []

    def fetch_recent_trades(self, symbol=None):
        """Fetch recent trades for a symbol or all trading pairs"""
        try:
            if symbol:
                trades = self.exchange.fetch_my_trades(symbol)
            else:
                trades = []
                for pair in self.config['trading_pairs']:
                    trades.extend(self.exchange.fetch_my_trades(pair))
            return trades
        except Exception as e:
            st.warning(f"Could not fetch recent trades: {e}")
            return []

    def parse_log_line(self, line):
        """Enhanced log line parsing with more comprehensive information"""
        try:
            parts = line.split(" | ")
            
            # Balance update parsing
            if "Balance updated to:" in line:
                try:
                    balance_match = line.split("Balance updated to:")[-1].strip()
                    balance = float(balance_match)
                    timestamp = parts[0] if parts else datetime.now().isoformat()
                    return {
                        "type": "balance", 
                        "timestamp": timestamp, 
                        "value": balance
                    }
                except Exception:
                    return None
            
            # Signal generation parsing
            elif "Signal Generation:" in line:
                try:
                    signal_str = line.split("Signal Generation: Generated Signal:")[-1].strip()
                    signal_data = json.loads(signal_str)
                    timestamp = parts[0] if parts else datetime.now().isoformat()
                    return {
                        "type": "signal", 
                        "timestamp": timestamp, 
                        "value": {
                            "symbol": signal_data.get("symbol", "Unknown"),
                            "action": signal_data.get("action", "hold"),
                            "confidence": signal_data.get("confidence", 0.0),
                            "score": signal_data.get("score", 0.0),
                            "price": signal_data.get("price", 0.0),
                            "reasons": signal_data.get("reasons", [])
                        }
                    }
                except Exception:
                    return None
            
            return None
        except Exception as e:
            logger.error(f"Unexpected error parsing log line: {e}")
            return None

    def load_trading_data(self):
        """Load comprehensive trading data from log file"""
        try:
            with open(self.log_file_path, 'r') as f:
                logs = f.readlines()
            
            balance_data = []
            signal_data = []
            
            for line in logs:
                parsed = self.parse_log_line(line)
                if parsed:
                    if parsed["type"] == "balance":
                        balance_data.append({
                            "timestamp": parsed["timestamp"],
                            "balance": parsed["value"]
                        })
                    elif parsed["type"] == "signal":
                        signal_data.append({
                            "timestamp": parsed["timestamp"],
                            **parsed["value"]
                        })
            
            balance_df = pd.DataFrame(balance_data)
            signal_df = pd.DataFrame(signal_data)
            
            if not balance_df.empty:
                balance_df["timestamp"] = pd.to_datetime(balance_df["timestamp"])
            if not signal_df.empty:
                signal_df["timestamp"] = pd.to_datetime(signal_df["timestamp"])
            
            return balance_df, signal_df
        except Exception as e:
            st.error(f"Error loading trading data: {e}")
            return pd.DataFrame(), pd.DataFrame()

    def display_metrics(self, balance_df, signal_df):
        """Display comprehensive trading metrics"""
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            # Live balance
            live_balance = self.fetch_live_balance()
            st.metric("Live Balance", f"${live_balance:.2f}" if live_balance is not None else "Unavailable")
        
        with col2:
            # Latest signal
            if not signal_df.empty:
                latest_signal = signal_df.iloc[-1]
                st.metric("Latest Signal", 
                    f"{latest_signal['symbol']}: {latest_signal['action'].upper()}", 
                    delta=f"Confidence: {latest_signal['confidence']:.2%}"
                )
            else:
                st.metric("Latest Signal", "No data")
        
        with col3:
            # Open trades
            open_trades = self.fetch_open_trades()
            st.metric("Open Trades", len(open_trades))
        
        with col4:
            # Trading pairs
            st.metric("Trading Pairs", len(self.config['trading_pairs']))

    def plot_balance_history(self, balance_df):
        """Plot balance history with enhanced visualization"""
        if not balance_df.empty:
            fig = go.Figure()
            fig.add_trace(go.Scatter(
                x=balance_df["timestamp"],
                y=balance_df["balance"],
                mode='lines+markers',
                name='Balance',
                line=dict(color='green', width=2),
                marker=dict(size=8, color='darkgreen')
            ))
            fig.update_layout(
                title="Balance History",
                xaxis_title="Time",
                yaxis_title="Balance (USDT)",
                height=400,
                template='plotly_white'
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No balance history available")

    def plot_signal_history(self, signal_df):
        """Plot signal history with comprehensive details"""
        if not signal_df.empty:
            # Create subplot with signal strength and score
            fig = go.Figure(data=[
                go.Scatter(
                    x=signal_df["timestamp"],
                    y=signal_df["confidence"],
                    mode='lines+markers',
                    name='Signal Strength',
                    marker=dict(
                        color=np.where(signal_df["action"] == "buy", "green", "red"),
                        size=8
                    )
                ),
                go.Scatter(
                    x=signal_df["timestamp"],
                    y=signal_df["score"],
                    mode='lines+markers',
                    name='Signal Score',
                    marker=dict(
                        color=np.where(signal_df["action"] == "buy", "blue", "orange"),
                        size=8
                    )
                )
            ])
            
            fig.update_layout(
                title="Signal Analysis",
                height=600,
                template='plotly_white',
                showlegend=False
            )
            
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No signal history available")

    def get_latest_signal(self):
        """Retrieve the latest trading signal from log file"""
        try:
            # Read the log file and extract the most recent signal
            with open(self.log_file_path, 'r') as log_file:
                log_lines = log_file.readlines()
                
                # Reverse the lines to find the most recent signal
                for line in reversed(log_lines):
                    if 'SIGNAL:' in line:
                        return line.strip()
                
                return "No recent signal found"
        except Exception as e:
            st.warning(f"Could not read signal from log: {e}")
            return "Error retrieving signal"

    def setup_page_config(self):
        """Configure Streamlit page settings"""
        st.set_page_config(
            page_title="Crypto Trading Bot Dashboard",
            page_icon=":chart_with_upwards_trend:",
            layout="wide",
            initial_sidebar_state="expanded"
        )

    def fetch_open_positions(self):
        """Fetch open positions with value over $1"""
        try:
            # Suppress the rate limit warning
            self.exchange.options['warnOnFetchOpenOrdersWithoutSymbol'] = False
            
            # Fetch open positions for each trading pair
            open_positions = []
            for symbol in self.config['trading_pairs']:
                try:
                    # Fetch balance for the specific symbol
                    balance = self.exchange.fetch_balance()
                    free_balance = balance['free'].get(symbol.split('/')[0], 0)
                    current_price = self.exchange.fetch_ticker(symbol)['last']
                    
                    # Calculate position value
                    position_value = free_balance * current_price
                    
                    # Only add positions over $1
                    if position_value > 1:
                        open_positions.append({
                            'symbol': symbol,
                            'amount': free_balance,
                            'current_price': current_price,
                            'position_value': position_value
                        })
                except Exception as e:
                    st.warning(f"Could not fetch position for {symbol}: {e}")
            
            return open_positions
        except Exception as e:
            st.warning(f"Error fetching open positions: {e}")
            return []

    def calculate_global_pnl(self, open_positions):
        """Calculate global PnL for all open positions with precise calculations"""
        try:
            total_pnl = 0
            total_initial_value = 0
            pnl_details = []

            for position in open_positions:
                symbol = position['symbol']
                amount = position['amount']
                current_price = position['current_price']
                
                # Get entry price directly from log
                entry_price = self.get_entry_price(symbol.split('/')[0])
                
                # If entry price not found, skip this position
                if entry_price is None:
                    st.warning(f"Could not find entry price for {symbol}")
                    continue
                
                # Calculate PnL
                price_difference = current_price - entry_price
                position_value = amount * current_price  # Current position value in USDT
                initial_value = amount * entry_price    # Initial position value in USDT
                pnl = position_value - initial_value    # PnL in USDT
                pnl_percentage = (price_difference / entry_price) * 100
                
                # Add to totals
                total_pnl += pnl
                total_initial_value += initial_value
                
                pnl_details.append({
                    'symbol': symbol,
                    'amount': round(amount, 8),
                    'entry_price': f'{entry_price:.8f}',
                    'current_price': f'{current_price:.8f}',
                    'price_difference': f'{price_difference:.8f}',
                    'pnl': round(pnl, 2),
                    'pnl_percentage': round(pnl_percentage, 2)
                })
            
            # Calculate global percentage
            global_pnl_percentage = (total_pnl / total_initial_value * 100) if total_initial_value > 0 else 0
            
            return round(total_pnl, 2), round(global_pnl_percentage, 2), pnl_details
        except Exception as e:
            st.warning(f"Error calculating global PnL: {e}")
            return 0, 0, []

    def display_positions_and_pnl(self):
        """Display open positions and PnL in a Streamlit table"""
        try:
            # Fetch open positions
            open_positions = self.fetch_open_positions()
            
            # Calculate global PnL
            global_pnl, global_pnl_percentage, pnl_details = self.calculate_global_pnl(open_positions)
            
            # Display open positions
            st.subheader("Open Positions")
            if open_positions:
                positions_df = pd.DataFrame(open_positions)
                st.dataframe(positions_df)
            else:
                st.info("No open positions over $1")
            
            # Display PnL details
            st.subheader("Position PnL Details")
            if pnl_details:
                # Convert to DataFrame and format percentage
                pnl_df = pd.DataFrame(pnl_details)
                
                # Format PnL percentage with % sign
                pnl_df['pnl_percentage'] = pnl_df['pnl_percentage'].apply(lambda x: f"{x:+.2f}%" if x != 0 else "0.00%")
                
                # Apply color styling
                def color_pnl(val):
                    try:
                        # For numeric values (pnl column)
                        if isinstance(val, (int, float)):
                            return f'color: {"green" if val > 0 else "red" if val < 0 else "black"}'
                        # For percentage strings
                        elif isinstance(val, str) and '%' in val:
                            val_num = float(val.replace('%', '').replace('+', ''))
                            return f'color: {"green" if val_num > 0 else "red" if val_num < 0 else "black"}'
                        return ''
                    except:
                        return ''
                
                # Apply styling to PnL and percentage columns
                styled_df = pnl_df.style.map(
                    color_pnl,
                    subset=['pnl', 'pnl_percentage']
                )
                
                st.dataframe(styled_df)
            else:
                st.info("No PnL details available")
            
            # Display Global PnL with proper delta coloring
            if global_pnl != 0:
                # Determine color based on PnL value
                pnl_color = "green" if global_pnl > 0 else "red"
                
                # Format PnL value and percentage with color
                pnl_value = f'<span style="color: {pnl_color}">${global_pnl:.2f}</span>'
                pnl_percentage = f'<span style="color: {pnl_color}">{global_pnl_percentage:+.2f}%</span>'
                
                # Display colored values
                st.markdown("### Global PnL")
                st.markdown(f"**Value:** {pnl_value}", unsafe_allow_html=True)
                st.markdown(f"**Change:** {pnl_percentage}", unsafe_allow_html=True)
            else:
                st.markdown("### Global PnL")
                st.markdown("**Value:** $0.00")
                st.markdown("**Change:** 0.00%")
        
        except Exception as e:
            st.error(f"Error displaying positions and PnL: {e}")
            st.error(f"Traceback: {traceback.format_exc()}")
            
    def get_entry_price(self, symbol):
        """
        Retrieve the last buy price for a given symbol using multiple methods:
        1. Check active trades dictionary
        2. Fetch recent order history from exchange
        3. Retrieve trade history
        """
        try:
            # Ensure symbol is in the correct format
            if '/' not in symbol:
                symbol = f"{symbol}/USDT"
            
            # Method 1: Check active trades from trading bot
            if hasattr(self, 'bot') and symbol in self.bot.active_trades:
                return self.bot.active_trades[symbol].get('entry_price')
            
            # Method 2: Fetch recent order history from exchange
            try:
                # Fetch recent orders for this symbol
                orders = self.exchange.fetch_orders(symbol, limit=50)
                
                # Filter and find the most recent buy order
                buy_orders = [
                    order for order in orders 
                    if order['side'] == 'buy' and order['status'] == 'closed'
                ]
                
                if buy_orders:
                    # Sort buy orders by timestamp, most recent first
                    latest_buy_order = sorted(
                        buy_orders, 
                        key=lambda x: x.get('timestamp', 0), 
                        reverse=True
                    )[0]
                    
                    # Return the average price of the buy order
                    return latest_buy_order.get('average', latest_buy_order.get('price'))
            except Exception as exchange_err:
                st.warning(f"Exchange order fetch error for {symbol}: {exchange_err}")
            
            # Method 3: Fetch recent trades
            try:
                trades = self.exchange.fetch_my_trades(symbol, limit=50)
                
                # Filter buy trades
                buy_trades = [
                    trade for trade in trades 
                    if trade['side'] == 'buy'
                ]
                
                if buy_trades:
                    # Sort trades by timestamp, most recent first
                    latest_buy_trade = sorted(
                        buy_trades, 
                        key=lambda x: x.get('timestamp', 0), 
                        reverse=True
                    )[0]
                    
                    return latest_buy_trade.get('price')
            except Exception as trades_err:
                st.warning(f"Exchange trades fetch error for {symbol}: {trades_err}")
            
            # Fallback: Check log file (previous method)
            with open(self.log_file_path, 'r') as log_file:
                log_lines = log_file.readlines()
                
                # Reverse the lines to find the most recent entry price
                for line in reversed(log_lines):
                    if f"Trade executed for {symbol}" in line or \
                       f"Buying {symbol}" in line or \
                       f"Entry price for {symbol}:" in line:
                        try:
                            # Split by various potential delimiters
                            price_candidates = [
                                line.split("price:")[-1].strip(),
                                line.split("price =")[-1].strip(),
                                line.split("at price")[-1].strip(),
                                line.split("@")[-1].strip()
                            ]
                            
                            # Try to convert each candidate to a float
                            for candidate in price_candidates:
                                try:
                                    return float(candidate.split()[0])
                                except (ValueError, IndexError):
                                    continue
                        except Exception:
                            continue
            
            return None
        except Exception as e:
            st.warning(f"Comprehensive error retrieving entry price for {symbol}: {e}")
            return None

    def display_log_analysis(self):
        try:
            # Read the last 500 lines of the log file to ensure we have enough data
            log_file = Path("logs/trading_bot.log")
            if not log_file.exists():
                st.warning("Log file not found")
                return

            with open(log_file, 'r') as f:
                lines = f.readlines()[-500:]  # Increased to 500 lines

            # Get active trading pairs from config
            active_pairs = self.config.get('trading_pairs', [])
            if not active_pairs:
                st.warning("No active trading pairs found in config")
                return

            # Create tabs for active pairs
            tabs = st.tabs(active_pairs)

            for pair, tab in zip(active_pairs, tabs):
                with tab:
                    # Prepare to collect data
                    pair_data = {
                        'market_analysis': None,
                        'signal': None,
                        'price': None
                    }
                    
                    # Reverse search through log lines
                    for line in reversed(lines):
                        try:
                            # Look for market analysis and signal lines for this pair
                            if pair in line:
                                if "Market Analysis" in line:
                                    try:
                                        # Parse market analysis JSON
                                        market_analysis = json.loads(line.split("Market Analysis for " + pair + ": ")[1])
                                        pair_data['market_analysis'] = market_analysis
                                        pair_data['price'] = market_analysis.get('price')
                                    except Exception as e:
                                        logger.warning(f"Error parsing market analysis for {pair}: {e}")
                                        continue

                                if "Signal Generation" in line and "Generated Signal" in line:
                                    try:
                                        # Parse signal JSON
                                        signal = json.loads(line.split("Generated Signal: ")[1])
                                        pair_data['signal'] = signal
                                    except Exception as e:
                                        logger.warning(f"Error parsing signal for {pair}: {e}")
                                        continue

                        except Exception as e:
                            logger.error(f"Unexpected error processing log line for {pair}: {e}")
                        
                        # Check if we have all required data
                        if all(pair_data.values()):
                            break
                    
                    # Display the collected data
                    if all(pair_data.values()):
                        # Determine status and color
                        action = pair_data['market_analysis'].get('action', 'hold').lower()
                        status_color = {
                            'buy': 'green',
                            'sell': 'red',
                            'hold': 'gray'
                        }.get(action, 'gray')

                        # Display pair status and price
                        st.markdown(f"### {pair} <span style='color: {status_color}'>●</span>", unsafe_allow_html=True)
                        st.markdown(f"**Current Price:** ${pair_data['price']:.4f}", unsafe_allow_html=True)

                        # Display market analysis details
                        st.markdown("#### Market Analysis")
                        
                        # Confidence and score
                        confidence_color = 'green' if pair_data['market_analysis'].get('confidence', 0) > 0.5 else 'gray'
                        st.markdown(f"**Confidence:** <span style='color: {confidence_color}'>{pair_data['market_analysis'].get('confidence', 0):.2f}</span>", 
                                    unsafe_allow_html=True)
                        st.markdown(f"**Score:** {pair_data['market_analysis'].get('score', 0):.2f}")

                        # Reasons for analysis
                        reasons = pair_data['market_analysis'].get('reasons', [])
                        if reasons:
                            st.markdown("**Reasons:**")
                            for reason in reasons:
                                st.markdown(f"- {reason}")

                        # Signal details
                        st.markdown("#### Signal Details")
                        signal_color = {
                            'buy': 'green',
                            'sell': 'red',
                            'hold': 'gray'
                        }.get(pair_data['signal'].get('action', 'hold').lower(), 'gray')
                        
                        st.markdown(
                            f"**Action:** <span style='color: {signal_color}'>{pair_data['signal'].get('action', 'HOLD').upper()}</span>", 
                            unsafe_allow_html=True
                        )
                        st.markdown(
                            f"**Confidence:** <span style='color: {signal_color}'>{pair_data['signal'].get('confidence', 0):.2f}</span>", 
                            unsafe_allow_html=True
                        )
                        st.markdown(f"**Score:** {pair_data['signal'].get('score', 0):.2f}")

                    else:
                        st.warning(f"No complete data found for {pair}")

        except Exception as e:
            st.error(f"Error displaying log analysis: {str(e)}")
            logger.error(f"Error in display_log_analysis: {str(e)}\n{traceback.format_exc()}")

    def parse_market_analysis_logs(self, log_file):
        market_data = {}
        
        # Ensure all configured trading pairs are initialized
        for pair in self.config.get('trading_pairs', []):
            market_data[pair] = {
                'market_analysis': [],
                'signal_generation': []
            }
        
        try:
            with open(log_file, 'r') as f:
                log_lines = f.readlines()
        
            # Reverse the log lines to get the most recent entries first
            log_lines.reverse()
        
            for line in log_lines:
                # Market Analysis log entries
                market_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}).*Market Analysis for (\w+/USDT): (\{.*\})', line)
                if market_match:
                    timestamp = market_match.group(1)
                    pair = market_match.group(2)
                    try:
                        analysis = json.loads(market_match.group(3))
                        
                        # Store market analysis details
                        market_analysis = {
                            'timestamp': timestamp,
                            'action': analysis.get('action', 'unknown'),
                            'confidence': analysis.get('confidence', 0.0),
                            'score': analysis.get('score', 0.0),
                            'price': analysis.get('price', 0.0),
                            'reasons': analysis.get('reasons', [])
                        }
                        
                        # Add to the pair's market analysis details
                        market_data[pair]['market_analysis'].append(market_analysis)
                    except json.JSONDecodeError:
                        pass
            
                # Signal Generation log entries
                signal_match = re.search(r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d{3}).*Signal Generation: Generated Signal: (\{.*\})', line)
                if signal_match:
                    timestamp = signal_match.group(1)
                    try:
                        signal = json.loads(signal_match.group(2))
                        
                        # Find the corresponding pair
                        pair_match = re.search(r'Market Analysis for (\w+/USDT)', line)
                        if pair_match:
                            pair = pair_match.group(1)
                            
                            # Store signal details
                            signal_details = {
                                'timestamp': timestamp,
                                'action': signal.get('action', 'unknown'),
                                'confidence': signal.get('confidence', 0.0),
                                'score': signal.get('score', 0.0),
                                'price': signal.get('price', 0.0),
                                'reasons': signal.get('reasons', [])
                            }
                            
                            # Add to the pair's signal details
                            market_data[pair]['signal_generation'].append(signal_details)
                    except json.JSONDecodeError:
                        pass
    
        except Exception as e:
            st.error(f"Error parsing log file: {e}")
    
        return market_data

    def display_technical_analysis(self):
        st.header("🔍 Technical Analysis")
        
        # Parse log file
        market_data = self.parse_market_analysis_logs(self.config.get('logging', {}).get('file', 'logs/trading_bot.log'))
        
        # Get configured trading pairs from config
        trading_pairs = self.config.get('trading_pairs', [])
        
        # Create columns for each trading pair
        cols = st.columns(len(trading_pairs))
        
        for i, pair in enumerate(trading_pairs):
            with cols[i]:
                st.subheader(f"{pair} Analysis")
                
                # Get pair data
                pair_data = market_data.get(pair, {})
                
                # Prioritize Market Analysis, fall back to Signal Generation
                market_analysis = pair_data.get('market_analysis', [])
                signal_generation = pair_data.get('signal_generation', [])
                
                # Combine and sort by timestamp
                all_signals = market_analysis + signal_generation
                all_signals.sort(key=lambda x: x['timestamp'], reverse=True)
                
                if all_signals:
                    # Use the most recent signal
                    latest_signal = all_signals[0]
                    
                    # Display Action
                    action = latest_signal['action'].upper()
                    action_color = 'green' if action == 'BUY' else 'red' if action == 'SELL' else 'gray'
                    st.markdown(f"**Action:** <span style='color:{action_color}'>{action}</span>", unsafe_allow_html=True)
                    
                    # Display Details
                    st.markdown(f"**Timestamp:** {latest_signal['timestamp']}")
                    st.markdown(f"**Confidence:** {latest_signal['confidence']:.2%}")
                    st.markdown(f"**Score:** {latest_signal['score']:.2f}")
                    st.markdown(f"**Price:** ${latest_signal['price']:.6f}")
                    
                    # Display Reasons
                    reasons = latest_signal['reasons']
                    if reasons:
                        st.markdown("**Reasons:**")
                        for reason in reasons:
                            st.markdown(f"- {reason}")
                    else:
                        st.markdown("*No specific reasons provided*")
                else:
                    st.warning("No signal data available for this pair")

    def _get_indicator_color(self, indicator: str, value: float) -> str:
        """Return appropriate color for technical indicators."""
        if indicator == 'rsi':
            if value > 70:
                return 'red'  # Overbought
            elif value < 30:
                return 'green'  # Oversold
            return 'gray'
        elif indicator == 'adx':
            if value > 25:
                return 'green'  # Strong trend
            return 'gray'
        elif indicator in ['adx_pos', 'adx_neg']:
            if value > 20:
                return 'green'  # Strong directional movement
            return 'gray'
        return 'gray'

    def run(self):
        """Main dashboard run method with enhanced controls"""
        st.title("Advanced Trading Dashboard")
        
        # Display positions and PnL
        self.display_positions_and_pnl()
        
        # Add log analysis section
        st.markdown("---")
        st.subheader("Technical Analysis")
        self.display_technical_analysis()

def main():
    dashboard = AdvancedTradingDashboard()
    
    while True:
        try:
            # Run the main trading logic
            dashboard.run()
            
            # Wait for a specified interval before next iteration
            time.sleep(60)  # 1-minute interval, adjust as needed
        
        except Exception as e:
            # Log any errors
            logger.error(f"Error in main trading loop: {e}")
            logger.error(traceback.format_exc())
            
            # Wait before retrying to prevent rapid error loops
            time.sleep(60)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Trading bot stopped manually.")
        sys.exit(0)
    except Exception as e:
        logger.error(f"Unhandled exception: {e}")
        logger.error(traceback.format_exc())
        sys.exit(1)
